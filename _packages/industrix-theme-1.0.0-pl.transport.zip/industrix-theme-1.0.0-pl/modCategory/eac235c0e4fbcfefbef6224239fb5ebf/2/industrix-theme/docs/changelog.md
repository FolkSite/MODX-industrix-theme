# Industrix Theme 1.0.0
- Basic Package with Config Extra. Grid, Gallery, Listing, and Page Layouts via MXT Theme System.
