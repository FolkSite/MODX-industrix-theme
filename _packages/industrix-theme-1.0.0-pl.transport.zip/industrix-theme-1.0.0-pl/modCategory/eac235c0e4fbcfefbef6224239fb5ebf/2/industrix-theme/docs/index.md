# Industrix Theme

MODX 2.4 Theme with nearly every layout combination possible in the MXT Theme Framework.
