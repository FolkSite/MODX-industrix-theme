<?php

$output = 'After installation, Visit http://www.getmdl.io/ for framework documentation.
<br />
<label for="install_resources">Install sample content:</label>
<select name="install_resources" id="install_resources">
    <option value="">No</option>
    <option value="yes">Yes</option>
</select>';

return $output;
